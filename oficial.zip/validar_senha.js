   <script>
    function validar_Senha(){
        senha1 = document.f1.senha1.value
        senha2 = document.f1.senha2.value

        if (senha1 == senha2)
            alert("As duas senhas são iguais...\nRealizaríamos as ações do caso positivo")
        else
            alert("As duas senhas são diferentes...\nRealizaríamos as ações do caso negativo")
			</script>
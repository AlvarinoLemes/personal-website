   <script>
   function validar_email(){
        email1 = document.f1.email1.value
        email2 = document.f1.email2.value

        if (email1 == email2)
            alert("Os dois emails são iguais...\nRealizaríamos as ações do caso positivo")
        else
            alert("Os dois emails são diferentes...\nRealizaríamos as ações do caso negativo")
			
			</script>